package mx.edu.utez.mensajes4a

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val edtMensaje = findViewById<EditText>(R.id.edtMensaje)
        val btnToast = findViewById<Button>(R.id.btnToast)
        val btnAlert = findViewById<Button>(R.id.btnAlert)
        val btnLog = findViewById<Button>(R.id.btnLog)
        val btnSnackBar = findViewById<Button>(R.id.btnSnackBar)




        ////BOTON TOAST
        btnToast.setOnClickListener {
            Toast.makeText(
                this@MainActivity,
                edtMensaje.text.toString(),
                Toast.LENGTH_SHORT
            ).show()
        }

        ///BOTON ALERTDIALOG
        btnAlert.setOnClickListener {
            val  builder = AlertDialog.Builder(this@MainActivity)
            builder.setTitle("Este es el titulo")
            builder.setMessage(edtMensaje.text.toString())
            /////POSITIVO
            builder.setPositiveButton("Si"){dialog, type ->
                dialog.dismiss()

            }
            ///NEGATIVO
            builder.setNegativeButton("No"){dialog, type ->
                dialog.dismiss()
            }
            /// NEUTRAL
            builder.setNeutralButton("Mas Tarde"){dialog, type ->
                dialog.dismiss()
            }
            builder.show()
        }


                /////BOTON LOG
            ////ESTO IMPRIME EN LOGCAT
        btnLog.setOnClickListener {
            Log.e("ERROR", edtMensaje.text.toString())
            Log.i("INFO", edtMensaje.text.toString())
            Log.w("WARNING", edtMensaje.text.toString())
        }

        ///funciona igual que TOAST pero este imprime el mensaje EN LA RAMA PRINCIPAL DE LAYOUT, que es CONSTRAINT
        btnSnackBar.setOnClickListener {
            val snack = Snackbar.make(

                findViewById(R.id.constraint),//<- no se usa contexto,
                //Se coloca la vista a la cual se pega el snackbar el
                edtMensaje.text.toString(),
                Snackbar.LENGTH_SHORT
            )
            snack.setAction("Boton"){
                println("Hice Algo")
            }
            snack.show()


        }





        }
    }



